import java.util.Scanner;
import java.util.Random;
public class ruotaVenezia {
    //stampare 5 numeri casuali che hanno un valore
    //fare un metodo che si chiama ruota estratta e ci fà ritornare un array con un valore casuale
    public static void main(String[] args) {
        int valore=0;
        int ruota=0;
        int [] numeriUsciti=new int [6];//creazione dell'array
        Scanner keyboard=new Scanner(System.in);
        System.out.println("scegli la ruota che può andare da 1 a 11");
        ruota= keyboard.nextInt();
        while (ruota<=0 || ruota>11){ // controllo della ruota
            System.out.println("il numero della ruota è sbagliato,reinserisci un'altro valore");
            ruota= keyboard.nextInt();
        }
      for(int i=0;i<6;i++){//un for che applica il valore random ad una cella dell'array
          valore=random(0,90);
          numeriUsciti[i]=valore;
      }
      for (int contatore=1;contatore< numeriUsciti.length;contatore++){
            System.out.println("il valore numero " +contatore+ " è "+ numeriUsciti[contatore]);//mostra in output i valori dell'array
        }
    }
    public static int random(int minValue, int maxValue){
        Random casuale=new Random();
        return casuale.nextInt(minValue,maxValue);
    }

}
